package tn.esprit.gestion.test;

import tn.esprit.gestion.models.Livraison;
import tn.esprit.gestion.services.LivraisonService;
import tn.esprit.gestion.utils.MyDatabase;

import java.sql.SQLException;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        MyDatabase db = MyDatabase.getInstance();

        /* try {
            LivraisonService livraisonService = new LivraisonService();

            livraisonService.ajouter(new Livraison(   "kasserine", "2023-12-04 14:34:44", "2023-12-06 17:34:44", "en cours"));
            System.out.println("cavaaaa !!!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    */
        /*
        try {
            int id;
            LivraisonService ps = new LivraisonService();
            ps.modifier(new Livraison( id:7,"kasserine", "2024-12-04 14:34:44", "2024-12-06 17:34:44", "en cours"  ));
            System.out.println("jawha bhy !!!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

       */
        /*try {
            int id;
            LivraisonService ps = new LivraisonService();
            ps.supprimer(5);
            System.out.println("jawha bhy !!!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

         */


            LivraisonService ps = new LivraisonService();
        try {
            ps.ajouter(new Livraison("beja", "2024-12-12 ", "2023-12-15 16:16:44", "encours"));
            ps.ajouter(new Livraison("kasserine", "2024-12-12 ", "2023-12-15 11:18:44", "arrivee"));
            ps.supprimer(1);
            System.out.println(ps.recuperer());
        }catch (SQLException e) {
            System.out.println("cavaaaa !!!!");
        }

    }






}











