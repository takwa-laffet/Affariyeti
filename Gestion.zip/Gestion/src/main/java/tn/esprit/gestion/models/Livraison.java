package tn.esprit.gestion.models;

public class Livraison {
    private int id;
    private String adresselivraison;
    private String datecommande;
    private String datelivraison;
    private String statuslivraison;



    //constructeur de recuperation des donnees
    public Livraison(int id, String adresselivraison, String datecommande, String datelivraison, String statuslivraison) {
        this.id = id;
        this.adresselivraison = adresselivraison;
        this.datecommande = datecommande;
        this.datelivraison = datelivraison;
        this.statuslivraison = statuslivraison;
    }

//const de l'ajout
public Livraison(int i) {
}
    public Livraison(String adresselivraison, String datecommande, String datelivraison, String statuslivraison) {
        this.adresselivraison = adresselivraison;
        this.datecommande = datecommande;
        this.datelivraison = datelivraison;
        this.statuslivraison = statuslivraison;
    }

    public Livraison() {

    }


    public int getId() {
        return id;
    }

    public String getAdresselivraison() {
        return adresselivraison;
    }
    public String getDatecommande() {
        return datecommande;
    }

    public String getDatelivraison() {
        return datelivraison;
    }
    public String getStatuslivraison() {
        return statuslivraison;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setAdresselivraison(String adresselivraison) {
        this.adresselivraison = adresselivraison;
    }
    public void setDatecommande(String datecommande) {
        this.datecommande = datecommande;
    }

    public void setDatelivraison(String datelivraison) {
        this.datelivraison = datelivraison;
    }
    public void setStatuslivraison(String statuslivraison) {
        this.statuslivraison = statuslivraison;
    }

    @Override
    public String toString() {
        return "livraison{" +
                "id=" + id +
                ", adresselivraison='" + adresselivraison + '\'' +
                ", datecommande=" + datecommande +
                ", datelivraison=" + datelivraison +
                ", statuslivraison='" + statuslivraison + '\'' +
                '}';
    }

}
