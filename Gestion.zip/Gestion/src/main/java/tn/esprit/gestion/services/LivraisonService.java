package tn.esprit.gestion.services;
import tn.esprit.gestion.models.Livraison;
import tn.esprit.gestion.utils.MyDatabase;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class LivraisonService implements Lservice<Livraison> {
    private  Connection connection;
    private Livraison livraison;

    public LivraisonService() {
        connection = MyDatabase.getInstance().getConnection();
    }


    @Override
    public void ajouter(Livraison livraison) throws SQLException{
        String req = "INSERT INTO livraison (adresselivraison,datecommande,datelivraison,statuslivraison) VALUES ('"+livraison.getAdresselivraison()+"','"+livraison.getDatecommande()+"','"+livraison.getDatelivraison()+"','"+livraison.getStatuslivraison()+"')";
        Statement st =connection.createStatement();
        st.executeUpdate(req);


    }

    @Override
    public void modifier(Livraison livraison) throws SQLException {

        String req= "UPDATE livraison SET adresselivraison=?,datecommande=?,datelivraison=?,statuslivraison=? WHERE id=?";
        PreparedStatement ps = connection.prepareStatement(req);
        ps.setString(1, livraison.getAdresselivraison());
        ps.setString(2, livraison.getDatecommande());
        ps.setString(3, livraison.getDatelivraison());
        ps.setString(4, livraison.getStatuslivraison());
        ps.setInt(5, livraison.getId());
       ps.executeUpdate();
    }



    @Override
    public void supprimer(int id) throws SQLException {
        String req = "DELETE FROM livraison WHERE id=?";
        try {
            PreparedStatement ps = connection.prepareStatement(req);
            ps.setInt( 1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public List<Livraison> recuperer() throws SQLException {
        List<Livraison> livraisons = new ArrayList<>();
        String req = "SELECT * FROM livraison";
        Statement st =connection.createStatement();
     ResultSet rs = st.executeQuery(req);

     while(rs.next()){
         Livraison livraison = new Livraison();
         livraison.setId(rs.getInt("id"));
         livraison.setAdresselivraison(rs.getString("adresselivraison"));
         livraison.setDatecommande(rs.getString("datecommande"));
         livraison.setDatelivraison(rs.getString("datelivraison"));
         livraison.setStatuslivraison(rs.getString("statuslivraison"));
         livraisons.add(livraison);
     }
     return livraisons;



    }
}

